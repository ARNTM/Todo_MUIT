<div style="background-color:white; color:black">

<h3 align="center">Integración de Servicios Telemáticos</h3>

<img src="./figuras/UPVcolor300.png" align="left" height="40">
<img src="./figuras/DCOM.png" align="right" height="40">


<img src="./figuras/Teleco.png"       align="left" style="clear:left; padding-top:10px" height="40">


<img src="./figuras/MUIT_2.png"       align="right" style="clear:right; padding-top: 10px" height="40">
<h1 align="center"><b>Proyecto de asignatura</b></h1>
<h3 align="center">Máster Universitario en Ingeniería de Telecomunicación</h3>
<h3 align="center">ETSIT-UPV</h3>



# LogBookDrone App 

<h1 align="center"><b>Interfaz de la web</b></h1>  
  
El proyecto es una página web para registrar operaciones llevadas a cabo por una empresa de vuelos de pilotos de drones. Un LogBook de drones es un requisito para toda empresa operadora (ej: una aerolínea) para ofrecer un registro de todos los vuelos, drones y sus respectivos pilotos.   
  <p align = "center">
     <img src="https://user-images.githubusercontent.com/91331999/152690264-682a94ee-2386-4bc8-86d5-ed0484ba2ae0.png" width = "200" height="400">
  
  
  

Para el funcionamiento de un LogBook de drones son necesarios dos tipos de roles: operador y usuario (piloto), además de los administradores de la web.
Un operador es una persona/empresa que posee una flota de drones, los cuales pueden ser utilizados por pilotos. Legalmente, han de estar registrados dichos drones, sus pilotos y la actividad realizada por cada dron.  
 
  
  
Una vez el operador se ha registrado con su código de operador (único), podrá hacer uso de las funcionalidades de la página web (registro de pilotos, de drones y de vuelos) y no podrá volver volver a cambiar su código a no ser que se ponga en contacto con los administradores.  

  <img src = "https://user-images.githubusercontent.com/91331999/152780459-29b09eff-0424-4388-a43d-a3f79e4b0963.png">


  
Para registrar pilotos, el usuario con este rol cumplimentará el nombre, correo electrónico y la licencia del mismo. Mediante el formulario que se muestra a continuación se puede llevar un control de todos los pilotos siendo imposible tener dos con el mismo número de licencia.
  
  <img src = "https://user-images.githubusercontent.com/91331999/152780537-9449ec00-071c-4b98-9e53-6f719a8a778a.png"> 
  
  

Respecto a la flota de drones del operador, este deberá proporcionar el nombre del fabricante, el modelo, el número de serie y la masa máxima de despegue (MTOM) para identificar cada aeronave.  

  <img src = "https://user-images.githubusercontent.com/91331999/152780623-c9828547-8a5c-4cc5-85b3-538c335179cf.png">

    
El piloto únicamente podrá hacer uso del registro de vuelos en el que podrá especificar los siguientes parámetros: lugar, dron, fecha, hora de vuelo y piloto. Cuando el operador registra un piloto, deberá contactar con los administradores de la página para otorgarle el rol necesario. 

  <img src = "https://user-images.githubusercontent.com/91331999/152693170-49575633-1866-4cf3-a406-2a26f88d91a8.png">

  
  Para acceder como usuario al LogBookDrone se ofrecen las siguientes credenciales:  
    
    - Usuario: upvoperator@logbookdrone.es ; Contraseña: #upvoperator  
    - Usuario: upvpilot@logbookdrone.es    ; Contraseña: #upvpilot
    
    
 <h1 align="center"><b>Desarrollo de la web</b></h1>  
  
Para el diseño de la web se ha hecho uso de una plantilla en Angular 12 siendo programado en TypeScript junto a HTML. Para el almacenamiento, gestión y proceso de autenticación se ha empleado Firebase con opción de iniciar sesión con Google o correo electrónico, además la web se puede visitar en https://logbookdrone.es , también alojado en Firebase.  
  
Se han utilizado formularios reactivos de Angular para la creación de los registros. Los roles se relacionan tal y como se ve en la siguiente figura.
<img src="./figuras/esquema_roles.png">
  
  
  
 
## Development server

Ejecutar 'ng serve' para lanzar el servidor de desarrollo. 

## Production server

https://logbookdrone.es -> Para acceder a la página web. 


