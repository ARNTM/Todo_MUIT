import { Injectable } from '@angular/core';
import { getFirebaseBackend } from '../../authUtils';
import firebase from 'firebase/app';
import 'firebase/auth';
import 'firebase/firestore';
import { AuthenticationService } from './auth.service';
import { Role } from '../models/auth.models';
import { EmailValidator } from '@angular/forms';

interface Usuario {
  role: string,
  email: string,
  id: string
}

interface Drone {
  manufacturer: string,
  model: string,
  sn: string,
  mtom: string
}
interface Flight {
  place: string, 
  date: string,
  time: string,
  drone: string,
  pilot: string,
  operator: string
}

interface Pilot {
  operator: string,
  name: string,
  license: string,
  email: string
}

interface Operator {
  name: string,
  id: string,
  number: string
}

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private _auth: AuthenticationService) { }

  getUserList() {
    let usuarios: Usuario[] = []
    firebase.firestore().collectionGroup('users').get().then(function (querySnapshot) {
      
      querySnapshot.forEach((doc) => {
        let usuario: Usuario = {
          role: doc.data().role,
          email: doc.data().name,
          id: doc.data().uid
        }
        usuarios.push(usuario)
      })
    })
    return usuarios
  }

  changeRoleOfUser(id, role) {
    firebase.firestore().collection('users').doc(id).update({
      role: role
    })
  }

  writeOperatorOnDatabase(uid,number, name) {
    firebase.firestore().collection(`operator`).add({
      id: uid,
      number: number,
      name: name
    })
  }

  writeDroneOnDatabase(uid, operator, manufacturer, model, sn, mtom) {
    firebase.firestore().collection(`drones`).add({
      uid: uid,
      operator: operator,
      manufacturer: manufacturer,
      model: model,
      sn: sn,
      mtom: mtom
    })
  }

  writePilotOnDatabase(uid, email, operator, name, license) {
    firebase.firestore().collection(`pilot`).add({
      operator: operator,
      name: name,
      email: email,
      license: license
    })
  }

  writeFlightOnDatabase(uid, place, date, time, pilot, drone, operator) {
    firebase.firestore().collection(`flight`).add({
      place: place, 
      date: date,
      time: time,
      drone: drone,
      pilot: pilot,
      operator: operator
    })
  }

  async getOperatorNumber(id) {
    let data: any[] = []
    await firebase.firestore().collection('operator').where('id', '==', id).get().then(function (querySnapshot) {
      querySnapshot.forEach((doc) => {
        data.push(doc.data())
      })
    }).catch(function (error) {
      return error
    })
    return data
  }

  readOperatorDataWithId(id) {
    let data: any[] = []
    firebase.firestore().collection('operator').where('uid', '==', id).get().then(function (querySnapshot) {
      querySnapshot.forEach((doc) => {
        data.push(doc.data())
      })
    }).catch(function (error) {
      return error
    })
    return data
  }

  readPilotDataWithLicense(license) {
    let data: any[] = []
    firebase.firestore().collection('pilot').where('license', '==', license).get().then(function (querySnapshot) {
      querySnapshot.forEach((doc) => {
        data.push(doc.data())
      })
    }).catch(function (error) {
      return error
    })
    return data
  }

  async searchDroneBySN(sn) {
    let data: any[] = []
    await firebase.firestore().collection('drones').where('sn', '==', sn).get().then(function (querySnapshot) {
      querySnapshot.forEach((doc) => {
        data.push(doc.data())
      })
    }).catch(function (error) {
      return error
    })
    return data
  }

async removeDroneBySN(sn) {
    let data: any[] = []
    await firebase.firestore().collection('drones').where('sn', '==', sn).get().then(function (querySnapshot) {
      querySnapshot.forEach((doc) => {
        doc.ref.delete()
      })
    }).catch(function (error) {
      return error
    })
    return true
  }

  
  async searchPilotByLicense(license) {
    let data: any[] = []
    await firebase.firestore().collection('pilot').where('license', '==', license).get().then(function (querySnapshot) {
      querySnapshot.forEach((doc) => {
        let pilot: Pilot = {
          operator: doc.data().operator,
          name: doc.data().name,
          email: doc.data().email,
          license: doc.data().license
        }
        data.push(pilot)
      })
    }).catch(function (error) {
      return error
    })
    return data
  }


  async removePilotByLicense(license) {
    let data: any[] = []
    await firebase.firestore().collection('pilot').where('license', '==', license).get().then(function (querySnapshot) {
      querySnapshot.forEach((doc) => {
        doc.ref.delete()
      })
    }).catch(function (error) {
      return error
    })
    return true
  }

  async searchDroneByActualUserUid(id) {
    let data: Drone[] = []
    await firebase.firestore().collection('drones').where('operator', '==', id).get().then(function (querySnapshot) {
      querySnapshot.forEach((doc) => {
        let drone: Drone = {
          manufacturer: doc.data().manufacturer,
          model: doc.data().model,
          sn: doc.data().sn,
          mtom: doc.data().mtom
        }
        data.push(drone)
      })
    }).catch(function (error) {
      return error
    })
    return data
  }

  async searchPilotByActualUserUid(id) {
    let data: Pilot[] = []
    await firebase.firestore().collection('pilot').where('operator', '==', id).get().then(function (querySnapshot) {
      querySnapshot.forEach((doc) => {
        let drone: Pilot = {
          operator: doc.data().operator,
          name: doc.data().name,
          email: doc.data().email,
          license: doc.data().license
        }
        data.push(drone)
      })
    }).catch(function (error) {
      return error
    })
    return data
  }

  async getOperatorNumberWhenPilot(email) {
    let data: Pilot[] = []
    await firebase.firestore().collection('pilot').where('email', '==', email).get().then(function (querySnapshot) {
      querySnapshot.forEach((doc) => {
        let drone: Pilot = {
          operator: doc.data().operator,
          name: doc.data().name,
          email: doc.data().email,
          license: doc.data().license
        }
        data.push(drone)
      })
    }).catch(function (error) {
      return error
    })
    return data
  }

  searchFlightByActualUserUid(id) {
    let data: Flight[] = []
    firebase.firestore().collection('flight').where('operator', '==', id).get().then(function (querySnapshot) {
      querySnapshot.forEach((doc) => {
        let drone: Flight = {
          place: doc.data().place, 
          date: doc.data().date,
          time: doc.data().time,
          drone: doc.data().drone,
          pilot: doc.data().pilot,
          operator: doc.data().operator
        }
        data.push(drone)
      })
    }).catch(function (error) {
      return error
    })
    return data
  }

  searchFlightByActualUserUidAndOperator(id, uiduser) {
    let data: Flight[] = []
    firebase.firestore().collection('flight').where('operator', '==', id).where('pilot', '==', uiduser).get().then(function (querySnapshot) {
      querySnapshot.forEach((doc) => {
        let drone: Flight = {
          place: doc.data().place, 
          date: doc.data().date,
          time: doc.data().time,
          drone: doc.data().drone,
          pilot: doc.data().pilot,
          operator: doc.data().operator
        }
        data.push(drone)
      })
    }).catch(function (error) {
      return error
    })
    return data
  }

  readCollectionDatabase(table) {
    let data: any[] = []
    firebase.firestore().collection(table).get().then(function (querySnapshot) {
      querySnapshot.forEach((doc) => {
        data.push(doc.data())
      })
    }).catch(function (error) {
      return error
    })
    return data
  }

}