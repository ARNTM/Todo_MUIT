import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { AuthenticationService } from '../services/auth.service';

import { environment } from '../../../environments/environment';
import { Role } from '../models/auth.models';

@Injectable({ providedIn: 'root' })
export class RoleGuard implements CanActivate {
    constructor(
        private router: Router,
        private authenticationService: AuthenticationService,
    ) { }

    role: string

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        const currentUser = this.authenticationService.currentUser();
        if (currentUser !== null){
            this.authenticationService.getRole(currentUser).then((res: any) => {
                this.role = res
                //console.log(res)
            })

            if (route.data.roles.includes(this.role)) {
                //console.log(true)
                return true;
            }
            // not logged in so redirect to login page with the return url
            else {
                this.router.navigate(['/']);
                return false;
            }
        }
        
    }
}
