export class User {
    uid: number;
    username?: string;
    password?: string;
    displayName: string;
    photoURL: string;
    emailVerified: boolean;
    firstName?: string;
    lastName?: string;
    token?: string;
    email: string;
    role?: string;
}

export enum Role {
    ADMIN = 'admin',
    MEMBER = 'member',
    PILOT = 'pilot',
    OPERATOR = 'operator'
}