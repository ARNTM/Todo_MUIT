import firebase from 'firebase/app';
// Add the Firebase products that you want to use
import 'firebase/auth';
import 'firebase/firestore';
import { User } from './core/models/auth.models';

class FirebaseAuthBackend {

    private role!: string;

    constructor(firebaseConfig) {
        if (firebaseConfig) {
            // Initialize Firebase
            firebase.initializeApp(firebaseConfig);
            firebase.auth().onAuthStateChanged((user) => {
                if (user) {
                    localStorage.setItem('authUser', JSON.stringify(user));
                } else {
                    localStorage.removeItem('authUser');
                }
            });
        }
    }

    GoogleAuth() {
        return this.AuthLogin(new firebase.auth.GoogleAuthProvider());
      }  
    
    // Auth logic to run auth providers
    AuthLogin(provider) {

    return new Promise((resolve, reject) => {
        firebase.auth().signInWithPopup(provider).then((user: any) => {
            // eslint-disable-next-line no-redeclareç
            var user: any = user.user;
            this.getDDBBUserRole(user).then((role) => {
                if (role == undefined) {
                    firebase.firestore().collection('users').doc(user.uid).set({
                        uid: user.uid,
                        role: 'operator',
                        name: user.email
                })
            }}).catch((error) => {
                reject(error);
            })
            resolve(user);
        }, (error) => {
            reject(this._handleError(error));
        });
    });
    }

    /**
     * Registers the user with given details
     */
    registerUser = (email, password, name, registerType) => {
        return new Promise((resolve, reject) => {
            firebase.auth().createUserWithEmailAndPassword(email, password).then((user: any) => {
                var user: any = firebase.auth().currentUser;
                firebase.firestore().collection('users').doc(user.uid).set({
                    uid: user.uid,
                    role: registerType,
                    name: user.email
                }).then(() => {
                    firebase.auth().currentUser.updateProfile({
                        displayName: name,
                        photoURL: 'assets/images/users/avatar-1.jpg'
                    }).then(() => {
                        this.role = registerType;
                        resolve(user);
                    }).catch((error) => {
                        reject(error)
                    })
                }).catch((error) => {
                    reject(error);
                });
                //resolve(user);
            }, (error) => {
                reject(this._handleError(error));
            });
        });
    }

    /**
     * Login user with given details
     */
    loginUser = (email, password) => {
        return new Promise((resolve, reject) => {
            firebase.auth().signInWithEmailAndPassword(email, password).then((user: any) => {
                // eslint-disable-next-line no-redeclare
                var user: any = firebase.auth().currentUser;
                //user.role = this.getDDBBUserRole(user)
                this.getDDBBUserRole(user)
                resolve(user);
            }, (error) => {
                reject(this._handleError(error));
            });
        });
    }

    async getDDBBUserRole(user: User): Promise<string> {
        await firebase.firestore().doc('users/' + user.uid).get().then((doc) => {
            if (doc.exists) {
                const role = doc.data().role;
                this.role = role;
                return this.role;
            }
        });
        return this.role;
    }

    /**
     * forget Password user with given details
     */
    forgetPassword = (email) => {
        return new Promise((resolve, reject) => {
            // tslint:disable-next-line: max-line-length
            firebase.auth().sendPasswordResetEmail(email, { url: window.location.protocol + '//' + window.location.host + '/login' }).then(() => {
                resolve(true);
            }).catch((error) => {
                reject(this._handleError(error));
            });
        });
    }

    /**
     * Logout the user
     */
    logout = () => {
        return new Promise((resolve, reject) => {
            firebase.auth().signOut().then(() => {
                resolve(true);
            }).catch((error) => {
                reject(this._handleError(error));
            });
        });
    }

    setLoggeedInUser = (user) => {
        localStorage.setItem('authUser', JSON.stringify(user));
    }

    /**
     * Returns the authenticated user
     */
    getAuthenticatedUser = () => {
        if (!localStorage.getItem('authUser')) {
            return null;
        }
        return JSON.parse(localStorage.getItem('authUser'));
    }

    actualUserUid = () => {
        if (firebase.auth().currentUser !== null) 
            return firebase.auth().currentUser.uid
    }

    /**
     * Handle the error
     * @param {*} error
     */
    _handleError(error) {
        // tslint:disable-next-line: prefer-const
        var errorMessage = error.message;
        return errorMessage;
    }
}

// tslint:disable-next-line: variable-name
let _fireBaseBackend = null;

/**
 * Initilize the backend
 * @param {*} config
 */
const initFirebaseBackend = (config) => {
    if (!_fireBaseBackend) {
        _fireBaseBackend = new FirebaseAuthBackend(config);
    }
    return _fireBaseBackend;
};

/**
 * Returns the firebase backend
 */
const getFirebaseBackend = () => {
    return _fireBaseBackend;
};

export { initFirebaseBackend, getFirebaseBackend };
