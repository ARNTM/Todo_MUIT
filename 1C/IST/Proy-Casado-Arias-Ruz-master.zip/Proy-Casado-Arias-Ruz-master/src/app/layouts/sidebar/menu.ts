import { MenuItem } from './menu.model';

export const MENU: MenuItem[] = [
    {
        id: 1,
        label: 'LBD_MENU.MENU_TEXT',
        isTitle: true,
        roleAvailable: ['admin', 'member', 'pilot', 'operator'],
    },
    {
        id: 2,
        label: 'LBD_MENU.DASHBOARD_TEXT',
        icon: 'bx-home-circle',
        link: '/',
        roleAvailable: ['admin', 'member',  'pilot', 'operator'],
    },
    {
        id: 3,
        label: 'LBD_MENU.FUNCTIONS_TEXT',
        isTitle: true,
        roleAvailable: ['admin', 'pilot', 'operator'],
    },
    {
        id: 4,
        label: 'LBD_MENU.OPERATOR_TEXT',
        icon: 'bx bxs-book',
        link: '/operator',
        roleAvailable: ['operator', 'admin'],
    },
    {
        id: 5,
        label: 'LBD_MENU.PILOT_TEXT',
        icon: 'bx bxs-group',
        link: '/pilots',
        roleAvailable: ['admin', 'operator'],
    },
    {
        id: 6,
        label: 'LBD_MENU.DRONE_TEXT',
        icon: 'bx bxs-plane-alt',
        link: '/drones',
        roleAvailable: ['admin', 'operator'],
    },
    {
        id: 7,
        label: 'LBD_MENU.FLIGHT_TEXT',
        icon: 'bx bxs-cloud',
        link: '/flights',
        roleAvailable: ['admin', 'pilot', 'operator'],
    },
    {
        id: 8,
        label: 'LBD_MENU.ADMIN_TEXT',
        isTitle: true,
        roleAvailable: ['admin'],
    },
    {
        id: 9,
        label: 'LBD_MENU.USERMAN_TEXT',
        icon: 'bx bxs-group',
        link: '/usersManager',
        roleAvailable: ['admin'],
    }
];

