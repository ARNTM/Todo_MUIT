import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { OperatorComponent } from './operator/operator.component';
import { PilotsComponent } from './pilots/pilots.component';
import { DronesComponent } from './drones/drones.component';
import { FlightsComponent } from './flights/flights.component';
import { AuthGuard } from '../core/guards/auth.guard';
import { HomeComponent } from './home/home.component';
import { GestionUsuariosComponent } from './gestion-usuarios/gestion-usuarios.component';
import { RoleGuard } from '../core/guards/role.guard';
import { Role } from '../core/models/auth.models';

const allRoles = [Role.ADMIN, Role.OPERATOR, Role.PILOT, Role.MEMBER];

const routes: Routes = [
  { path: '', component: HomeComponent, canActivate: [AuthGuard,RoleGuard], data: { roles: ['admin', 'member', 'operator', 'pilot']} },
  { path: 'operator', component: OperatorComponent, canActivate: [AuthGuard,RoleGuard], data: { roles: ['admin', 'member','operator']} },
  { path: 'pilots', component: PilotsComponent, canActivate: [AuthGuard,RoleGuard], data: { roles: ['admin', 'member','operator']} },
  { path: 'drones', component: DronesComponent, canActivate: [AuthGuard,RoleGuard], data: { roles: ['admin', 'member','operator']} },
  { path: 'flights', component: FlightsComponent, canActivate: [AuthGuard,RoleGuard], data: { roles: ['admin', 'member','operator','pilot']} },
  { path: 'usersManager', component: GestionUsuariosComponent, canActivate: [AuthGuard,RoleGuard], data: { roles: ['admin']} },


];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PagesRoutingModule { }
