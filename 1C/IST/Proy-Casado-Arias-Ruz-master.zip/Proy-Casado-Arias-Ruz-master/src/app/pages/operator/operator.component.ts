import { Component, OnInit, QueryList, ViewChildren } from '@angular/core';
import { AuthenticationService } from '../../core/services/auth.service';
import { DataService } from '../../core/services/data.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-operator',
  templateUrl: './operator.component.html',
  styles: [
  ]
})
export class OperatorComponent implements OnInit {

  constructor(private _auth: AuthenticationService, private _data: DataService, private formBuilder: FormBuilder) {
  }
  

  form: FormGroup
  submitted: boolean = false;
  success: boolean = false;
  error = '';

  operatorExist = false
  primeraCarga = true

  get f() { return this.form.controls; }

  // bread crum data
  breadCrumbItems: Array<{}>;
    
  ngOnInit(): void {
    this._data.getOperatorNumber(this._auth.actualUserUid()).then(data => {
      if(data[0].number != 0){
        this.operatorExist = true
        this.primeraCarga = false
      }
    }).catch( error =>
      this.primeraCarga = false
    )
    this.form = this.formBuilder.group({
      operatornumber: ['', [Validators.required]],
      operator: ['', [Validators.required]],
    })
  }

 async onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.form.invalid) {
      return;
    } else {
        this._data.writeOperatorOnDatabase(this._auth.actualUserUid(),this.f.operatornumber.value, this.f.operator.value)
        this.success = true;
        this.submitted = false;
        this.form.reset()
    }
  }
}
