// Table data
export interface Table {
    manufacturer: string
    model: string;
    sn: string;
    mtom: string;
}

// Search Data
export interface SearchResult {
    tables: Table[];
    total: number;
}
