import { Component, OnInit, QueryList, ViewChildren } from '@angular/core';
import { AuthenticationService } from '../../core/services/auth.service';
import { DataService } from '../../core/services/data.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdvancedService } from './advanced.service';
import { Table } from './advanced.model';
import { Observable } from 'rxjs';
import { AdvancedSortableDirective, SortEvent } from './advanced-sortable.directive';

interface Drone {
  manufacturer: string,
  model: string,
  sn: string,
  mtom: string
}

@Component({
  selector: 'app-drones',
  templateUrl: './drones.component.html',
  styles: [
  ]
})
export class DronesComponent implements OnInit {

  constructor(private _auth: AuthenticationService, private _data: DataService, private formBuilder: FormBuilder, public service: AdvancedService) {
    this.tables$ = service.tables$;
    this.total$ = service.total$; }

  form: FormGroup
  submitted: boolean = false;
  success = '';
  error = '';

  get f() { return this.form.controls; }

      // bread crum data
      breadCrumbItems: Array<{}>;
      // Table data
      tableData: Table[];
      public selected: any;
      hideme: boolean[] = [];
      tables$: Observable<Table[]>;
      total$: Observable<number>;
    
      @ViewChildren(AdvancedSortableDirective) headers: QueryList<AdvancedSortableDirective>;
      public isCollapsed = true;
      public primeraCarga = false;
  
      onSort({ column, direction }: SortEvent) {
        // resetting other headers
        this.headers.forEach(header => {
          if (header.sortable !== column) {
            header.direction = '';
          }
        });
        this.service.sortColumn = column;
        this.service.sortDirection = direction;
      }
  operator = 0;

  ngOnInit(): void {


    this._data.getOperatorNumber(this._auth.actualUserUid()).then(data => {
      this.operator = data[0].number
      this.tableData = this.service.getTableData(this.operator);
      this.form = this.formBuilder.group({
        operator: [{value: this.operator, disabled:"True"}, [Validators.required]],
        manufacturer: ['', [Validators.required]],
        model: ['', [Validators.required]],
        sn: ['', [Validators.required]],
        mtom: ['', [Validators.required]],
      })

      this.primeraCarga = true
    })
  }

  async borrarDrone(sn) {
    await this._data.removeDroneBySN(sn).then((data) => {
      if(data) {
        this.tableData = this.service.getTableData(this.operator)
      }
      
    })
    
  }

  async onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.form.invalid) {
      return;
    } else {

        const a = await this._data.searchDroneBySN(this.f.sn.value)
        if (a.length > 0) {
          this.error = 'Drone already exists'
          this.success = '';
          this.submitted = false;
          this.form = this.formBuilder.group({
            operator: [{value: this.operator, disabled:"True"}, [Validators.required]],
            manufacturer: ['', [Validators.required]],
            model: ['', [Validators.required]],
            sn: ['', [Validators.required]],
            mtom: ['', [Validators.required]],
          })
        }
        else {
          this._data.writeDroneOnDatabase(this._auth.actualUserUid(),this.f.operator.value, this.f.manufacturer.value, this.f.model.value, this.f.sn.value, this.f.mtom.value)
          this.success = 'Dron registrado correctamente';
          this.error = ''
          this.submitted = false;
          this.tableData = this.service.getTableData(this.operator);
          this.form = this.formBuilder.group({
            operator: [{value: this.operator, disabled:"True"}, [Validators.required]],
            manufacturer: ['', [Validators.required]],
            model: ['', [Validators.required]],
            sn: ['', [Validators.required]],
            mtom: ['', [Validators.required]],
          })
        }
    }
  }

}
