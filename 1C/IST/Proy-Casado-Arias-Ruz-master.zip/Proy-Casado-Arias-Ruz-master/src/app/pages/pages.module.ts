import { NgModule } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { NgbAlertModule, NgbNavModule, NgbDropdownModule, NgbModalModule, NgbTooltipModule , NgbCollapseModule, NgbCarouselModule, NgbAccordionModule, NgbPopoverModule, NgbProgressbarModule} from '@ng-bootstrap/ng-bootstrap';
import { NgApexchartsModule } from 'ng-apexcharts';
import { FullCalendarModule } from '@fullcalendar/angular';
import { SimplebarAngularModule } from 'simplebar-angular';
import dayGridPlugin from '@fullcalendar/daygrid'; // a plugin
import interactionPlugin from '@fullcalendar/interaction'; // a plugin
import bootstrapPlugin from "@fullcalendar/bootstrap";
import { LightboxModule } from 'ngx-lightbox';
import { NgSelectModule } from '@ng-select/ng-select';

import { NgbDatepickerModule } from '@ng-bootstrap/ng-bootstrap';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { ArchwizardModule } from 'angular-archwizard';
import { NgxMaskModule } from 'ngx-mask';
import { UiSwitchModule } from 'ngx-ui-switch';
import { ColorPickerModule } from 'ngx-color-picker';
import { DropzoneModule } from 'ngx-dropzone-wrapper';

import { WidgetModule } from '../shared/widget/widget.module';
import { UIModule } from '../shared/ui/ui.module';

import { PagesRoutingModule } from './pages-routing.module';

import { ChartsModule } from 'ng2-charts';
import { TranslateModule } from '@ngx-translate/core';

import { NgbPaginationModule, NgbTypeaheadModule } from '@ng-bootstrap/ng-bootstrap';
import { Ng2SmartTableModule } from 'ng2-smart-table';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { OperatorComponent } from './operator/operator.component';
import { PilotsComponent } from './pilots/pilots.component';
import { DronesComponent } from './drones/drones.component';
import { FlightsComponent } from './flights/flights.component';
import { HomeComponent } from './home/home.component';
import { GestionUsuariosComponent } from './gestion-usuarios/gestion-usuarios.component';
import { SharedModule } from '../shared/shared.module';

FullCalendarModule.registerPlugins([ // register FullCalendar plugins
  dayGridPlugin,
  interactionPlugin,
  bootstrapPlugin
]);

@NgModule({
  declarations: [
    OperatorComponent,
    PilotsComponent,
    DronesComponent,
    FlightsComponent,
    HomeComponent,
    GestionUsuariosComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    NgbDropdownModule,
    NgbModalModule,
    PagesRoutingModule,
    NgApexchartsModule,
    ReactiveFormsModule,
    HttpClientModule,
    UIModule,
    WidgetModule,
    FullCalendarModule,
    NgbNavModule,
    NgbTooltipModule,
    NgbCollapseModule,
    SimplebarAngularModule,
    LightboxModule,
    ChartsModule,
    TranslateModule,
    FormsModule,
    NgbPaginationModule, 
    NgbTypeaheadModule,
    NgSelectModule,
    NgbDatepickerModule,
    CKEditorModule,
    ArchwizardModule,
    NgxMaskModule.forRoot(),
    UiSwitchModule,
    ColorPickerModule,
    DropzoneModule,
    NgbAlertModule,
    NgbCarouselModule, 
    NgbProgressbarModule, 
    NgbPopoverModule, 
    NgbAccordionModule,
    Ng2SmartTableModule,
    SharedModule
  ],
})
export class PagesModule { }
