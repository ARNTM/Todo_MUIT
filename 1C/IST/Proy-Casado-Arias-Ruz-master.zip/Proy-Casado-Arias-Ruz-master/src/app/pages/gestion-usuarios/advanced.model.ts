import { Role } from '../../core/models/auth.models';
// Table data
export interface Table {
    id: string
    email: string;
    role: string;
}

// Search Data
export interface SearchResult {
    tables: Table[];
    total: number;
}
