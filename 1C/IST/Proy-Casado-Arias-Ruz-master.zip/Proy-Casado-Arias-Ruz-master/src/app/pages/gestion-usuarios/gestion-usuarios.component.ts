import { Component, OnInit, QueryList, ViewChildren } from '@angular/core';

import { DecimalPipe } from '@angular/common';

import { Observable } from 'rxjs';

import { Table } from './advanced.model';

import { AdvancedService } from './advanced.service';
import { AdvancedSortableDirective, SortEvent } from './advanced-sortable.directive';
import { DataService } from 'src/app/core/services/data.service';
import { AuthenticationService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-gestion-usuarios',
  templateUrl: './gestion-usuarios.component.html',
  providers: [AdvancedService, DecimalPipe]
})
export class GestionUsuariosComponent implements OnInit {

    // bread crum data
    breadCrumbItems: Array<{}>;
    // Table data
    tableData: Table[];
    public selected: any;
    hideme: boolean[] = [];
    tables$: Observable<Table[]>;
    total$: Observable<number>;
  
    @ViewChildren(AdvancedSortableDirective) headers: QueryList<AdvancedSortableDirective>;
    public isCollapsed = true;
    public primeraCarga = true;
  

    constructor(public service: AdvancedService, private _data: DataService, private _auth: AuthenticationService) {
      this.tables$ = service.tables$;
      this.total$ = service.total$;
    }

    ngOnInit() {
      this.tableData = this.service.getTableData();

      setInterval(() => {
        this.tableData = this.service.getTableData();
      }, 120000)

    }
  
    onSort({ column, direction }: SortEvent) {
      // resetting other headers
      this.headers.forEach(header => {
        if (header.sortable !== column) {
          header.direction = '';
        }
      });
      this.service.sortColumn = column;
      this.service.sortDirection = direction;
    }

    editarRol(id: string) {
      console.log(id)
    }
}