import { Component, OnInit, QueryList, ViewChildren } from '@angular/core';
import { AuthenticationService } from '../../core/services/auth.service';
import { DataService } from '../../core/services/data.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdvancedService } from './advanced.service'; 
import { Table } from './advanced.model';
import { Observable } from 'rxjs';
import { AdvancedSortableDirective, SortEvent } from './advanced-sortable.directive';

@Component({
  selector: 'app-pilots',
  templateUrl: './pilots.component.html',
  styles: [
  ]
})
export class PilotsComponent implements OnInit {

  constructor(private _auth: AuthenticationService, private _data: DataService, private formBuilder: FormBuilder, public service: AdvancedService) {
    this.tables$ = service.tables$;
    this.total$ = service.total$; 
   }

  form: FormGroup
  submitted: boolean = false;
  success = '';
  error = '';

  get f() { return this.form.controls; }

  // bread crum data
  breadCrumbItems: Array<{}>;
  // Table data
  tableData: Table[];
  public selected: any;
  hideme: boolean[] = [];
  tables$: Observable<Table[]>;
  total$: Observable<number>;

  @ViewChildren(AdvancedSortableDirective) headers: QueryList<AdvancedSortableDirective>;
  public isCollapsed = true;
  public primeraCarga = false;

  operator;

  ngOnInit(): void {
    this._data.getOperatorNumber(this._auth.actualUserUid()).then(data => {
      this.operator = data[0].number
      this.tableData = this.service.getTableData(this.operator);
      this.form = this.formBuilder.group({
        operator: [{value: this.operator, disabled:"True"}, [Validators.required]],
        name: ['', [Validators.required]],
        email: ['', [Validators.required]],
        license: ['', [Validators.required]],
      })

      this.primeraCarga = true
    })
  }


  async borrarPilot(license) {
    await this._data.removePilotByLicense(license).then((data) => {
      if(data) this.tableData = this.service.getTableData(this.operator)
    })
    
  }

  async onSubmit() {
    this.submitted = true;
    const a = await this._data.searchPilotByLicense(this.f.operator.value)
    // stop here if form is invalid
    if (this.form.invalid) {
      return;
    } else {

        const a = await this._data.searchPilotByLicense(this.f.license.value)
        if (a.length > 0) {
          this.error = 'Licencia ya existente'
          this.success = '';
          this.submitted = false;
          this.form = this.formBuilder.group({
            operator: [{value: this.operator, disabled:"True"}, [Validators.required]],
            name: ['', [Validators.required]],
            email: ['', [Validators.required]],
            license: ['', [Validators.required]],
          })
        }
        else {
          this._data.writePilotOnDatabase(this._auth.actualUserUid(),this.f.email.value, this.f.operator.value, this.f.name.value, this.f.license.value)
          this.success = 'Piloto registrado correctamente';
          this.error = ''
          this.submitted = false;
          this.tableData = this.service.getTableData(this.operator);
          this.form = this.formBuilder.group({
            operator: [{value: this.operator, disabled:"True"}, [Validators.required]],
            name: ['', [Validators.required]],
            email: ['', [Validators.required]],
            license: ['', [Validators.required]],
          })
        }
    }
  }

}
