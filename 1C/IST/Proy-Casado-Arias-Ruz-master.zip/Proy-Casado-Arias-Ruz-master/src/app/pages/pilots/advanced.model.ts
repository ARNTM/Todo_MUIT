// Table data
export interface Table {
    operator: string
    name: string;
    email: string;
    license: string;
}

// Search Data
export interface SearchResult {
    tables: Table[];
    total: number;
}
