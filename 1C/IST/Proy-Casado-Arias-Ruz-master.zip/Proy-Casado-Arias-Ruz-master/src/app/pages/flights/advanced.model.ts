// Table data
export interface Table {
    place: string, 
    date: string,
    time: string,
    drone: string,
    pilot: string,
    operator: string
}

// Search Data
export interface SearchResult {
    tables: Table[];
    total: number;
}
