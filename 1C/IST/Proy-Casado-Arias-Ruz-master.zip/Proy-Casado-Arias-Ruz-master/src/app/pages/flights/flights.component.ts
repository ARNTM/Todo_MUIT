import { Component, OnInit, QueryList, ViewChildren } from '@angular/core';
import { AuthenticationService } from '../../core/services/auth.service';
import { DataService } from '../../core/services/data.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdvancedService } from './advanced.service';
import { Table } from './advanced.model';
import { Observable } from 'rxjs';
import { AdvancedSortableDirective, SortEvent } from './advanced-sortable.directive';

@Component({
  selector: 'app-flights',
  templateUrl: './flights.component.html',
  styles: [
  ]
})
export class FlightsComponent implements OnInit {

  constructor(private _auth: AuthenticationService, private _data: DataService, private formBuilder: FormBuilder, public service: AdvancedService) {
    this.tables$ = service.tables$;
    this.total$ = service.total$; }
  

  form: FormGroup
  submitted: boolean = false;
  success: boolean = false;
  error = '';

  get f() { return this.form.controls; }

  // bread crum data
  breadCrumbItems: Array<{}>;
  // Table data
  tableData: Table[];
  public selected: any;
  hideme: boolean[] = [];
  tables$: Observable<Table[]>;
  total$: Observable<number>;

  @ViewChildren(AdvancedSortableDirective) headers: QueryList<AdvancedSortableDirective>;
  public isCollapsed = true;
  public primeraCarga = false;
  operator;
  aoperator;
    
  onSort({ column, direction }: SortEvent) {
    // resetting other headers
    this.headers.forEach(header => {
      if (header.sortable !== column) {
        header.direction = '';
      }
    });
    this.service.sortColumn = column;
    this.service.sortDirection = direction;
  }

  drones = []
  pilots = []
  role;

  ngOnInit(): void {
    this._auth.getRole(this._auth.actualUserUid).then(role => {
      if(role == 'pilot') {
        this.role = role;
        this._data.getOperatorNumberWhenPilot(this._auth.currentUser().email).then(operator => {
          this.operator = operator
          this.tableData = this.service.getTableData(this.operator[0].operator, this.operator[0].name);
          this.form = this.formBuilder.group({
            place: ['', [Validators.required]],
            date: ['', [Validators.required]],
            time: ['', [Validators.required]],
            pilot: [{value: operator[0].name, disabled:"True"}, [Validators.required]],
            drone: ['', [Validators.required]],
            operator: [{value: this.operator[0].operator, disabled:"True"}, [Validators.required]],
          })
          this._data.searchDroneByActualUserUid(this.operator[0].operator).then(data => {
            this.drones = data
            this.pilots.push({
              email: operator[0].email,
              name: operator[0].name,
              license: operator[0].license,
              operator: operator[0].operator,
            })
              this.primeraCarga = true
          })
        })
      }
      else {
        this._data.getOperatorNumber(this._auth.actualUserUid()).then(data => {
          this.aoperator = data[0].number
          //console.log(this.operator)
          this.tableData = this.service.getTableData(this.aoperator);
          this.form = this.formBuilder.group({
            place: ['', [Validators.required]],
            date: ['', [Validators.required]],
            time: ['', [Validators.required]],
            pilot: ['', [Validators.required]],
            drone: ['', [Validators.required]],
            operator: [{value: this.aoperator, disabled:"True"}, [Validators.required]],
          })
          this._data.searchDroneByActualUserUid(this.aoperator).then(data => {
            this.drones = data
            this._data.searchPilotByActualUserUid(this.aoperator).then(data => {
              this.pilots = data
              //console.log(data)
              this.primeraCarga = true
            })
          })
        })
      }
    })
}

 async onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.form.invalid) {
      return;
    } else {
        this._data.writeFlightOnDatabase(this._auth.actualUserUid(),this.f.place.value, this.f.date.value, this.f.time.value, this.f.pilot.value, this.f.drone.value, this.f.operator.value)
        this.success = true;
        this.submitted = false;
        if(this.role == 'pilot') {
          this.tableData = this.service.getTableData(this.operator[0].operator, this.operator[0].name);
          this.form = this.formBuilder.group({
            place: ['', [Validators.required]],
            date: ['', [Validators.required]],
            time: ['', [Validators.required]],
            pilot: [{value: this.operator[0].name, disabled:"True"}, [Validators.required]],
            drone: ['', [Validators.required]],
            operator: [{value: this.operator[0].operator, disabled:"True"}, [Validators.required]],
          })
        }
        else {
          this.tableData = this.service.getTableData(this.aoperator);
          this.form = this.formBuilder.group({
            place: ['', [Validators.required]],
            date: ['', [Validators.required]],
            time: ['', [Validators.required]],
            pilot: ['', [Validators.required]],
            drone: ['', [Validators.required]],
            operator: [{value: this.aoperator, disabled:"True"}, [Validators.required]],
          })
        }
    }
  }
}
