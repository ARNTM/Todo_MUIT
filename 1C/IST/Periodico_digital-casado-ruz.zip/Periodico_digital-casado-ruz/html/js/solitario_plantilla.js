



			/***** INICIO DECLARACIÓN DE VARIABLES GLOBALES *****/

			// Array de palos
      let palos = ["corazones", "picas", "rombos", "treboles"];
      
			// Array de número de cartas
			let numeros = ["as", 2, 3, 4, 5, 6, 7, 8, 9, 10, "jota", "reina", "rey"];
			// En las pruebas iniciales solo se trabará con cuatro cartas por palo:
			//let numeros = [10, "jota", "reina", "rey"];

      // paso (top y left) en pixeles de una carta a la anterior en un mazo
      let paso = 2;

			// Tapetes				
			let tapete_inicial   = document.getElementById("inicial");
			let tapete_sobrantes = document.getElementById("sobrantes");
			let tapete_receptor1 = document.getElementById("receptor1");
			let tapete_receptor2 = document.getElementById("receptor2");
			let tapete_receptor3 = document.getElementById("receptor3");
			let tapete_receptor4 = document.getElementById("receptor4");

			// Mazos
			let mazo_inicial   = [];
			let mazo_sobrantes = [];
			let mazo_receptor1 = [];
			let mazo_receptor2 = [];
			let mazo_receptor3 = [];
			let mazo_receptor4 = [];

			// Contadores de cartas
			let cont_inicial     = document.getElementById("cont_inicial");
			let cont_sobrantes   = document.getElementById("cont_sobrantes");
			let cont_receptor1   = document.getElementById("cont_receptor1");
			let cont_receptor2   = document.getElementById("cont_receptor2");
			let cont_receptor3   = document.getElementById("cont_receptor3");
			let cont_receptor4   = document.getElementById("cont_receptor4");
			let cont_movimientos = document.getElementById("cont_movimientos");

			// Tiempo
			let cont_tiempo  = document.getElementById("cont_tiempo"); // span cuenta tiempo
			let segundos 	   = 0;    // cuenta de segundos
			let temporizador = null; // manejador del temporizador

			/***** FIN DECLARACIÓN DE VARIABLES GLOBALES *****/

			 
			// Rutina asociada a boton reset: comenzar_juego
			document.getElementById("reset").onclick = comenzar_juego;

			// El juego debería comenzar al cargar la página: no se debe esperar a pulsar el botón de Reiniciar
      /* !!!!!!!!!!!!!!!!!!! CODIGO !!!!!!!!!!!!!!!!!!!!!!! */
	 		 comenzar_juego();
      /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */


			// Desarrollo del comienzo de juego
			function comenzar_juego() {
				
				vaciado_tapete(tapete_inicial);
				vaciado_tapete(tapete_sobrantes);
				vaciado_tapete(tapete_receptor1);
				vaciado_tapete(tapete_receptor2);
				vaciado_tapete(tapete_receptor3);
				vaciado_tapete(tapete_receptor4);

				/* Crear el mazo inicial con toda la baraja. Este será un array cuyos 
				elementos serán elementos HTML <img>, siendo cada uno de ellos una carta.
				Sugerencia: en dos bucles for, bárranse los "palos" y los "numeros", formando
				oportunamente el nombre del fichero png que contiene a la carta (recuérdese poner
				el path correcto en la URL asociada al atributo src de <img>). Una vez creado
				el elemento img, inclúyase como elemento del array mazo_inicial. 
				*/
				/* !!!!!!!!!!!!!!!!!!!!!! CODIGO !!!!!!!!!!!!!!!!!!!! */	
				mazo_inicial = []
				mazo_sobrantes = []
				mazo_receptor1	= []
				mazo_receptor2	= []
				mazo_receptor3	= []
				mazo_receptor4	= []


				for (i in palos) {
					for (j in numeros) {
						var carta = document.createElement("img");
						carta.src = `img/baraja/${numeros[j]}-${palos[i]}.png`;
						carta.setAttribute('width','70px');
						carta.setAttribute('id', `${numeros[j]}-${palos[i]}`);
						carta.setAttribute("data-numero", j);

						(palos[i]=="corazones" || palos[i]=="rombos") ? carta.setAttribute("data-palo", "rojo") : carta.setAttribute("data-palo", "negro")

						mazo_inicial.push(carta); 
					}
				}
                
        /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */
        

				// Barajar
				barajar(mazo_inicial);

				// Dejar mazo_inicial en tapete inicial
				cargar_tapete_inicial(mazo_inicial);

				// Puesta a cero de contadores de mazos
				set_contador(cont_sobrantes, 0);
				set_contador(cont_receptor1, 0);
				set_contador(cont_receptor2, 0);
				set_contador(cont_receptor3, 0);
				set_contador(cont_receptor4, 0);
				set_contador(cont_movimientos, 0);
				
				// Arrancar el conteo de tiempo
				arrancar_tiempo();
				habilitarCartaInicial();

			} // comenzar_juego


			function vaciado_tapete(tapete){
				var cartas = tapete.getElementsByTagName("img"), index;

				for (index = cartas.length - 1; index >= 0; index--) {
					cartas[index].parentNode.removeChild(cartas[index]);
				}
			}



			/**
				Se debe encargar de arrancar el temporizador: cada 1000 ms se
				debe ejecutar una función que a partir de la cuenta autoincrementada
				de los segundos (segundos totales) visualice el tiempo oportunamente con el 
				format hh:mm:ss en el contador adecuado.

				Para descomponer los segundos en horas, minutos y segundos pueden emplearse
				las siguientes igualdades:

				segundos = truncar (   segundos_totales % (60)                 )
				minutos  = truncar ( ( segundos_totales % (60*60) )     / 60   )
				horas    = truncar ( ( segundos_totales % (60*60*24)) ) / 3600 )

				donde % denota la operación módulo (resto de la división entre los operadores)

				Así, por ejemplo, si la cuenta de segundos totales es de 134 s, entonces será:
				   00:02:14

				Como existe la posibilidad de "resetear" el juego en cualquier momento, hay que 
				evitar que exista más de un temporizador simultáneo, por lo que debería guardarse
				el resultado de la llamada a setInterval en alguna variable para llamar oportunamente
				a clearInterval en su caso.   
			*/
			function arrancar_tiempo(){ // Ya completamente implementado: estúdiese
				if (temporizador) clearInterval(temporizador);
				let hms = function (){
				let seg = Math.trunc( segundos % 60 );
				let min = Math.trunc( (segundos % 3600) / 60 );
				let hor = Math.trunc( (segundos % 86400) / 3600 );
				let tiempo =  ( (hor<10)? "0"+hor : ""+hor ) 
						+ ":" + ( (min<10)? "0"+min : ""+min )  
						+ ":" + ( (seg<10)? "0"+seg : ""+seg );
				set_contador(cont_tiempo, tiempo);
				segundos++;
				}
				segundos = 0;
				hms(); // Primera visualización 00:00:00
				temporizador = setInterval(hms, 1000); // hms() será invocado cada segundo               	
			} // arrancar_tiempo

			



			
			/**
				Si mazo es un array de elementos <img>, en esta rutina debe ser
				reordenado aleatoriamente. Al ser un array un objeto, se pasa
				por referencia, de modo que si se altera el orden de dicho array
				dentro de la rutina, esto aparecerá reflejado fuera de la misma.
				Para reordenar el array puede emplearse el siguiente pseudo código:

				- Recorramos con i todos los elementos del array
					- Sea j un indice cuyo valor sea un número aleatorio comprendido 
						entre 0 y la longitud del array menos uno. Este valor aleatorio
						puede conseguirse, por ejemplo con la instrucción JavaScript
							Math.floor( Math.random() * LONGITUD_DEL_ARRAY );
					- Se intercambia el contenido de la posición i-ésima con el de la j-ésima

			*/
			function barajar(mazo) {
			  /* !!!!!!!!!!!!!!!!!!!!!! CODIGO !!!!!!!!!!!!!!!!!!!! */	
			  let carta_barajada;
			  const mazolenght = mazo.length;
			  for (carta in mazo) {
				posicionCarta = Math.floor(Math.random() * mazolenght);
				carta_barajada = mazo[carta];
				mazo[carta] = mazo[posicionCarta];
				mazo[posicionCarta] = carta_barajada;
			  }
        /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */
			} // barajar


			
			/**
			 	En el elemento HTML que representa el tapete inicial (variable tapete_inicial)
				se deben añadir como hijos de DOM todos los elementos <img> del array mazo actual.
				Antes de añadirlos, se deberían fijar propiedades como la anchura, la posición,
				coordenadas top y left, algun atributo de tipo data-...
				Al final se debe ajustar el contador de cartas a la cantidad oportuna
			*/
			function cargar_tapete_inicial(mazo) {

				barajar(mazo)
			  /* !!!!!!!!!!!!!!!!!!!!!! CODIGO !!!!!!!!!!!!!!!!!!!! */	
			  tapete_inicial.appendChild(cont_inicial);
				console.log(mazo)
			  let top = 0;
			  let left = 0;
				console.log('##################################')
			  for (carta in mazo) {
				mazo[carta].style.transform = "none"
				mazo[carta].style.position = "absolute";
				mazo[carta].style.top = `${top}px`;
				mazo[carta].style.left = `${left}px`;
				mazo[carta].draggable = false
				top+=paso;
				left+=paso;
				tapete_inicial.appendChild(mazo[carta]);
			  }

			  set_contador(cont_inicial, mazo.length);
        /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */	
			} // cargar_tapete_inicial


			/**
			 	Esta función debe incrementar el número correspondiente al contenido textual
			   	del elemento que actúa de contador
			*/
			function inc_contador(contador){
        contador.innerHTML = +contador.innerHTML + 1; // Obsérvese el operador + antes de contador.innerHTML
			} // inc_contador




			/**
				Idem que anterior, pero decrementando 
			*/
			function dec_contador(contador){
			  /* !!!!!!!!!!!!!!!!!!!!!! CODIGO !!!!!!!!!!!!!!!!!!!! */	
              contador.innerHTML = +contador.innerHTML - 1;  
        /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */	
			} // dec_contador

			/**
				Similar a las anteriores, pero ajustando la cuenta al
				valor especificado
			*/
			function set_contador(contador, valor) {
			  /* !!!!!!!!!!!!!!!!!!!!!! CODIGO !!!!!!!!!!!!!!!!!!!! */	
			  contador.innerHTML = valor;
        /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */	
			} // set_contador

			function habilitarCartaInicial() {
				var carta = document.getElementById("inicial").lastChild;
	
				carta.draggable = true; // Habilita el arrastre de la carta
	
				carta.ondragstart = al_mover;
				carta.ondragend = function() { }
				carta.ondrag = function(e) { };
			}

			function al_mover(e) { 
				let  datos = {target: e.target.id , tapete: this.parentElement.id};
				e.dataTransfer.setData( "text/plain", JSON.stringify(datos) ); 
				sobrante = document.getElementById("sobrantes").lastChild;
				r1 = document.getElementById("receptor1").lastChild;
				r2 = document.getElementById("receptor2").lastChild;
				r3 = document.getElementById("receptor3").lastChild;
				r4 = document.getElementById("receptor4").lastChild;
			 }

			 // SOBRANTE

			tapete_sobrantes.ondragenter = function(e) {
				e.preventDefault();
			}
			tapete_sobrantes.ondragover = function(e) {
				e.preventDefault();
			}
			tapete_sobrantes.ondragleave = function(e) {
				e.preventDefault();
			}
			tapete_sobrantes.ondrop = mover

			// RECEPTOR 1
			tapete_receptor1.ondragenter = function(e) {
				e.preventDefault();
			}
			tapete_receptor1.ondragover = function(e) {
				e.preventDefault();
			}
			tapete_receptor1.ondragleave = function(e) {
				e.preventDefault();
			}
			tapete_receptor1.ondrop = mover

			// RECEPTOR 2
			tapete_receptor2.ondragenter = function(e) {
				e.preventDefault();
			}
			tapete_receptor2.ondragover = function(e) {
				e.preventDefault();
			}
			tapete_receptor2.ondragleave = function(e) {
				e.preventDefault();
			}
			tapete_receptor2.ondrop = mover

			// RECEPTOR 3
			tapete_receptor3.ondragenter = function(e) {
				e.preventDefault();
			}
			tapete_receptor3.ondragover = function(e) {
				e.preventDefault();
			}
			tapete_receptor3.ondragleave = function(e) {
				e.preventDefault();
			}
			tapete_receptor3.ondrop = mover
			

			// RECEPTOR 4
			tapete_receptor4.ondragenter = function(e) {
				e.preventDefault();
			}
			tapete_receptor4.ondragover = function(e) {
				e.preventDefault();
			}
			tapete_receptor4.ondragleave = function(e) {
				e.preventDefault();
			}
			tapete_receptor4.ondrop = mover


			function mover(e) {
				e.preventDefault();
				var data = e.dataTransfer.getData("text");
				var datos = JSON.parse(data);
				var carta = document.getElementById(datos.target);

				var tapete = document.getElementById(this.id);
				
				switch(this.id) {
					case 'receptor1':
						if(comprobarMovimiento(carta, tapete)) {
							inc_contador(cont_movimientos)
							this.appendChild(carta);
							if (datos.tapete == "inicial") {
								mazo_inicial.pop(carta)
								set_contador(cont_inicial, mazo_inicial.length)
							}
							if (datos.tapete == "sobrantes") {
								mazo_sobrantes.pop(carta)
								set_contador(cont_sobrantes, mazo_sobrantes.length)
							}
							mazo_receptor1.push(carta);
							
							carta.draggable = false; 
							// SE HABILITA EL MOVIMIENTO DE LA SIGUIENTE CARTA DEL MAZO INICIAL
							habilitarCartaInicial();
							set_contador(cont_receptor1, mazo_receptor1.length)
						}
						else {
						}

					break;

					case 'receptor2':
						if(comprobarMovimiento(carta, tapete)){
							inc_contador(cont_movimientos)
							this.appendChild(carta);
							mazo_receptor2.push(carta);
							if (datos.tapete == "inicial") {
								mazo_inicial.pop(carta)
								set_contador(cont_inicial, mazo_inicial.length)
							}
							if (datos.tapete == "sobrantes") {
								mazo_sobrantes.pop(carta)
								set_contador(cont_sobrantes, mazo_sobrantes.length)
							}
							carta.draggable = false; 
							// SE HABILITA EL MOVIMIENTO DE LA SIGUIENTE CARTA DEL MAZO INICIAL
							habilitarCartaInicial();
							set_contador(cont_receptor2, mazo_receptor2.length)
						}
					break;

					case 'receptor3':
						if (comprobarMovimiento(carta, tapete)) {
							inc_contador(cont_movimientos)
							dec_contador(cont_inicial)
							this.appendChild(carta);
							mazo_receptor3.push(carta);
							if (datos.tapete == "inicial") {
								mazo_inicial.pop(carta)
								set_contador(cont_inicial, mazo_inicial.length)
							}
							if (datos.tapete == "sobrantes") {
								mazo_sobrantes.pop(carta)
								set_contador(cont_sobrantes, mazo_sobrantes.length)
							}
							carta.draggable = false; 
							// SE HABILITA EL MOVIMIENTO DE LA SIGUIENTE CARTA DEL MAZO INICIAL
							habilitarCartaInicial();
							set_contador(cont_receptor3, mazo_receptor3.length)
						}
					break;

					case 'receptor4':
						if (comprobarMovimiento(carta, tapete)) {
							inc_contador(cont_movimientos)
							dec_contador(cont_inicial)
							this.appendChild(carta);
							mazo_receptor4.push(carta);
							if (datos.tapete == "inicial") {
								mazo_inicial.pop(carta)
								set_contador(cont_inicial, mazo_inicial.length)
							}
							if (datos.tapete == "sobrantes") {
								mazo_sobrantes.pop(carta)
								set_contador(cont_sobrantes, mazo_sobrantes.length)
							}
							carta.draggable = false; 
							// SE HABILITA EL MOVIMIENTO DE LA SIGUIENTE CARTA DEL MAZO INICIAL
							habilitarCartaInicial();
							set_contador(cont_receptor4, mazo_receptor4.length)
						}
					break;

					case 'sobrantes':		
						if ( carta != sobrante) {
							carta.style.top = "50%"; 
							carta.style.left = "50%";
							carta.style.transform="translate(-50%, -50%)";
							inc_contador(cont_movimientos)
							this.appendChild(carta);
							mazo_sobrantes.push(carta);
							mazo_inicial.pop(carta);
							// SE HABILITA EL MOVIMIENTO DE LA SIGUIENTE CARTA DEL MAZO INICIAL
							set_contador(cont_sobrantes, mazo_sobrantes.length)
							set_contador(cont_inicial, mazo_inicial.length)
							habilitarCartaInicial();
						}
					break;
				}

				// ESTOY SIN CARTAS?

				if (mazo_inicial.length == 0 && mazo_sobrantes.length != 0) {
					mazo_inicial = mazo_sobrantes;
					mazo_sobrantes = [];
					set_contador(cont_inicial, mazo_inicial.length)
					set_contador(cont_sobrantes, mazo_sobrantes.length)
					var cartas = tapete_sobrantes.getElementsByTagName("img");
					cargar_tapete_inicial([...cartas])
					vaciado_tapete(tapete_sobrantes)
					habilitarCartaInicial();
				}


				// COMPROBACION FINAL
				if ((mazo_inicial.length == 0 && mazo_sobrantes == 0)) {
					setTimeout( function() {
						window.alert('Tiempo: ' +  cont_tiempo.innerHTML + '\n' + 'Movimientos: ' + cont_movimientos.innerHTML);
						comenzar_juego();
					}, 100);
				}
			}

			// FUNCION PARA COMPROBAR SI PUEDO MOVERME O NO
			function comprobarMovimiento(carta, datos) {
				if(
					(carta.getAttribute('data-numero') == (numeros.length-1) && datos.lastChild.getAttribute('data-numero') == null) || // 1ª COND
					((carta.getAttribute('data-numero') == datos.lastChild.getAttribute('data-numero') - 1) && carta.getAttribute('data-palo') != datos.lastChild.getAttribute('data-palo'))// 2ª COND
				) 
				{
					carta.style.top = "50%"; 
					carta.style.left = "50%";
					carta.style.transform="translate(-50%, -50%)";
					return true
				}
			}