<h3 align="center">Integración de Servicios Telemáticos</h3>

<img src="./figuras/UPVcolor300.png" align="left" height="75">

<img src="./figuras/ETSIT_UPV.png"       align="right" height="75">




<h1 align="center"><b>Periódico digital</b></h1>




<h3 align="center">Máster Universitario en Ingeniería de Telecomunicación</h3>
<h3 align="center">ETSIT-UPV</h3>



# Introducción y objetivos

Las prácticas de la asignatura _Integración de Servicios Telemáticos_ tendrán como objetivo adquirir la destreza mínima para poder abordar el diseño e implementación de un sencillo sitio web; en nuestro caso, el ejemplo escogido es el de un periódico digital con sus distintas secciones, contenidos y funcionalidades.  El ejemplo escogido nos servirá de hilo conductor para todas las prácticas, tratando de integrar gran parte de los conocimientos que se imparten en la asignatura;  por otra parte se espera que los alumnos, de forma autónoma, busquen y encuentren la solución a los problemas que se planteen y no hayan sido impartidos explícitamente en la asignatura.

El diseño y la implementación asociada irán evolucionando ya que la intención es partir de cero e ir rellenando, completando, modificando y rectificando estructuras, contenidos, estilos y funcionalidades para conseguir al final el resultado deseado. Un entorno con control de versiones es ideal para ir acumulando la progresión del trabajo e ir viéndolo y comparándolo en el tiempo, máxime en un entorno colaborativo. 

Por ello, la realización de las prácticas implicará la acumulación de _commits_ en el __presente__ repositorio __GitHub__ para todas las prácticas, es decir, __no cambiaremos de repositorio__: este será el único que se utilice durante todo el cuatrimestre para la realización de toda la serie de prácticas. Sin embargo, y por otra parte, __cada enunciado tendrá su repositorio particular__ que simplemente será empleado para la lectura del trabajo a realizar. Es decir tendremos por una parte enunciados en sus repositorios respectivos, y por otra parte la solución acumulada a estos enunciados en un único repositorio: este.

Recuérdese que la forma natural de trabajar será en un primer instante clonar este repositorio. Después, cada vez que se aborde una práctica habrá que interactuar con el repositorio local de manera oportuna para ir guardando el resultado del trabajo; en los instantes que se consideren oportunos habrá que interaccionar con el respositorio remoto para poder colaborar con el resto de compañeros. Esta estrategia de trabajo vendrá marcada por el denominado _flujo de trabajo_ del equipo, que será comentado posteriormente.




La labor del diseño e implementación, distribuida a lo largo de las prácticas, implicará el seguimiento de las indicaciones de los enunciados de las prácticas, ramificando y fusionando allá donde parezca oportuno, esperando que la colaboración remota entre los integrantes del grupo se refleje perfectamente en la evolución del repositorio. Recuérdese que se valorará muy positivamente, no solamente la calidad del trabajo realizado, sino la colaboración que se haya realizado para la elaboración de dicho trabajo;
si el grupo tiene solo un integrante, ello no impide que el codigo se ramifique tratando de implementar un flujo de trabajo de tipo funcional, por ejemplo, o cualquier otro que parezca oportuno.  


# Hardware y software necesario

El hardware necesario para realizar la siguiente práctica es un ordenador de cualquier arquitectura convencional: Windows, Mac OS X o Linux. Este ordenador puede ser indistintamente un ordenador  personal o los ordenadores del laboratorio donde se realicen las prácticas.

El software que vamos a utilizar o recomendar tiene versiones en las tres arquitecturas habituales: Windows, Mac OS X y Linux, con mínimas diferencias entre ellas, por lo que resultará indiferente que un alumno trabaje con una máquina u otra. 


Primeramente, y como es obvio, será necesario que en la máquina de trabajo esté instalado __Git__. 

Adicionalmente, se sugiere que el alumno elija personalmente un editor de texto plano con el que se encuentre cómodo. Nosotros recomendamos alguno como `Visual Studio Code`, `Sublime Text`, `Atom`, `NotePad++`,... cuya instalación queda a discreción del alumno. 


Se sugiere además que se tengan instalados varios navegadores, ya que en alguna ocasión se pueden presentar sutiles o no tan sutiles diferencias de comportamiento, como por ejemplo Google Chrome, Firefox, Safari, Edge, Opera,... Lo interesante es que tengan capacidades de depuración para poder averiguar la fuente de los problemas que surjan.

En cada práctica se sugerirá la instalación de software adicional que vaya a ser necesario.



# Lorem Ipsum...

Si la intención es diseñar un periódico, evidentemente este requerirá artículos para tener entidad como tal. Nuestra intención no es escribir estos artículos, sino simular de alguna forma la presencia de los mismos; es decir, y por decirlo de alguna manera, necesitamos _texto artificial_ para comprobar nuestros diseños e implementaciones. 

Si creamos este texto artificial copiando y pegando párrafos de forma repetitiva, pueden aparecer _patrones_ que hagan que no se parezca a un texto más o menos real. Para evitar estos problemas se suelen emplear textos _Lorem Ipsum_ ([Wiki Lorem Ipsum](https://es.wikipedia.org/wiki/Lorem_ipsum)). Existen generadores de este tipo de textos artificiales _on line_; un sitio entre otros es [lipsum.com](http://lipsum.com) en el que pueden generar para nosotros la cantidad de párrafos _lorem ipsum_ que especifiquemos; a continuación podremos _copiar y pegarlos_ en nuestro documento como texto _artificial_ o de _relleno_. En las prácticas se sugiere que hagamos uso de esta facilidad para crear texto artificial y completar de esa manera los artículos de manera rápida y efectiva; evidentemente aquel que desee introducir texto natural, original o copiado de alguna otra fuente, puede hacerlo sin mayor inconveniente. 

Hay otras alternativas que pueden requerir la instalación de alguna extensión o _plug-in_ en el editor de texto, con el que se puede conseguir un resultado cómodo e inmediato.


# Estructura de directorios

Al clonar el presente repositorio deberemos observar la siguiente estructura de repositorios en nuestro árbol o directorio de trabajo:



```tree
Periodico-digital-<NOMBRE_DEL_GRUPO>
 |  
 ├── cuestiones
 │    ├── practica1
 │    ├── practica2
 │    └── ...
 |    
 ├── figuras
 |  
 ├── html
 │    ├── img
 |    |    ├── internacional
 │    │    ├── logos
 │    │    │     ├── CPI.png
 │    │    │     ├── ETSIT_UPV.png
 │    │    │     └── logoUPV.png
 |    |    ├── nacional
 │    │    ├── ocio  
 |    |    ├── publicidad
 │    │    │    └── clickHere.jpg 
 │    │    └── ...
 │    ├── index.html
 │    ├── internacional.html
 │    ├── nacional.html
 │    ├── ocio.html
 │    └── ...
 │
 └── README.md
```


El fichero `README.md` y el directorio `figuras` contienen la información que en este momento se está visualizando.

El directorio `cuestiones` deberá contener una serie de directorios, uno por práctica o sesión de prácticas, incluyendo la información que se exija en cada sesión. Cada práctica, a parte de requerir ciertas implementaciones, podrá plantear algunas cuestiones a las que hay que responder a nivel de grupo. Estas respuestas se almacenarán en ficheros y estos se guardarán en estos subdirectorios. El texto con las respuestas se codificará en lenguaje Markdown, por lo que se sugiere que se estudie previamente en algún tutorial este sencillo lenguaje de codificación textual. Estos subdirectorios y los ficheros exigidos se irán creando con cada práctica. Cada enunciado de cada práctica dará las explicaciones oportunas para llevar a cabo esta labor.

El directorio `html` es el que contendrá todas las implementaciones requeridas. En este repositorio ya se proporciona una estructura sugerida de algunos ficheros y directorios. Puede tomarse como punto de partida para comenzar a trabajar.



# Flujo de trabajo _(workflow)_

Podemos interpretar el flujo de trabajo o _workflow_ en un sistema de control de versiones como la estrategia de trabajo a seguir en contextos de desarrollo habitualmente de software, aunque no de forma exclusiva.

Existen numerosas formas de llevar a cabo la organización del acceso a un repositorio de trabajo: centralizado, funcional, _gitflow_, _forking_, ... o incluso ninguna en particular. Algunas de estas estrategias pueden aplicarse a equipos de trabajo y también a individuos, dependiendo de la situación. 

El grupo de prácticas de dos personas o incluso el que esté formado por un único alumno, deberá decidir en algún momento la estrategia sobre cómo se va a llevar a cabo este flujo de trabajo. Adelantamos que esta cuestión será planteada en la primera práctica.



# Dudas, problemas, cuestiones...

El grupo de trabajo (individual o la pareja de alumnos) debería ser capaz de abordar todas las cuestiones que se planteen en cada enunciado de prácticas de forma autónoma. Es obvio que dependiendo de la destreza o experiencia previa de cada persona, se puede ser más o menos hábil  en resolver los problemas que a buen seguro van a surgir. En cualquier caso, siempre podéis consultar vuestras dudas con el profesorado y el mecanismo que se sugiere es plantear una _issue_ en este mismo repositorio por cada tema que queráis tratar, siendo __muy importante__ identificar claramente a los _assignees_ de cada _issue_ en cuestión: recordad que lo ideal es que os incluyáis todos los miembros del grupo y añadáis también al profesor al que queréis hacerle la consulta.



# Credenciales de usuario en máquinas del laboratorio

Dadas las circunstancias actuales, sería deseable, aunque no es estrictamente necesario, que cada alumno realizara la práctica en el laboratorio o aula informática con su portátil; de esa forma, toda la configuración del software a instalar se queda definitivamente hecha en su máquina personal. Si por el contrario, el alumno decide trabajar con una máquina del laboratorio o aula informática, los únicos detalles a tener en cuenta son, tras finalizar la sesión de prácticas en el laboratorio, borrar sus credenciales de `github.com` en el administrador de credenciales de Windows  y realizar un _Sign out_ desde su página personal de GitHub. 
