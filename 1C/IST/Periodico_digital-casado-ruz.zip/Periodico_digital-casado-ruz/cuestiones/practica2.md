# Práctica 2

1. Dependiendo de cómo se haya programado, probablemente se haya observado que la línea discontinua, borde inferior de los elementos `<article>`, se pinta antes de que aparezcan los símbolos de like y dislike, y no después, pero solo en los artículos desarrollados. Identifíquese el problema y propóngase algún tipo de solución.

No hemos tenido ese problema.

2. Si el uso de los iconos del sobre, pulgar arriba y pulgar abajo implicó solo el enlace con un recurso desde código HTML mediante un elemento `<link>`, ¿cómo podría hacerse desde un fichero CSS evitando entonces manipular el fichero HTML original?

Si se obtienen los iconos como una fuente podríamos crear un `@font-family` con esta. Posteriormente simplemente se añadirá la propiedad `font-family: "fa5"; ` (en nuestro caso) a cualquier clase donde se quieran usar estos iconos.