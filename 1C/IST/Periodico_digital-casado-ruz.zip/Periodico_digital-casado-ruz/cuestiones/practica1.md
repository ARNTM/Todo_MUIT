# Práctica 1

Se han realizado las 4 secciones por separado.

Jose Pedro ha realizado titulo_principal y central
Andrés Ruz ha realizado menú principal y footer.

Se ha seguido el siguiente Workflow, creando ramas para cada tarea:
![](img/1.png)
