#include "key_codes.h" 	// define los valores de KEY1, KEY2, KEY3
#include "system.h"
#include "sys/alt_irq.h"

extern volatile int hour;
extern volatile int min;

void pushbutton_ISR( )
{
	volatile int * KEY_ptr = (int *) PUSHBUTTONS_BASE;
	int press;

	press = *(KEY_ptr + 3);					// lee el registro de los pulsadores
	*(KEY_ptr + 3) = 0; 					// borra la interrupci�n

	if (press & 0x4)				// KEY2
		min++;
		if(min == 60) min = 0;
	else if (press & 0x8)					// KEY3
		hour++;
		if(hour == 24) hour = 0;

	return;
}
