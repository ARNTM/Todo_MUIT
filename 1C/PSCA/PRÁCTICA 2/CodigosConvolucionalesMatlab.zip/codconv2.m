function [palabracod] = codconv2(mensaje)

% palabracod = codconv2(mensaje)
%    C�digo convolucional

enrejado = poly2trellis(3,[5 4],5);
hEnc = comm.ConvolutionalEncoder(enrejado, 'TerminationMethod','Terminated');
palabracod = step(hEnc,mensaje);

end
