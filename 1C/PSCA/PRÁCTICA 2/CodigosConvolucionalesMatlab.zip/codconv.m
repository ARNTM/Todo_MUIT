function [palabracod] = codconv(mensaje)

% palabracod = codconv(mensaje)
%    C�digo convolucional

enrejado = poly2trellis([3 3],[4 1 2;1 6 1]);
hEnc = comm.ConvolutionalEncoder(enrejado, 'TerminationMethod','Terminated');
palabracod = step(hEnc,mensaje);

end

